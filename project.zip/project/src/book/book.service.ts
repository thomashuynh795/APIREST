import { Injectable } from '@nestjs/common';
import { CreateBookDTO, PatchBookDTO, UpdateBookDTO } from './book.dot';
import { Book } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class BookService {
  constructor(private prisma: PrismaService) {}

  public async create(dto: CreateBookDTO): Promise<Book> {
    const data: CreateBookDTO = {
      name: dto.name,
      author: dto.author,
      volumesCount: dto.volumesCount,
      mark: dto.mark,
      releaseDate: dto.releaseDate,
    };
    const book: Book = await this.prisma.book.create({
      data,
    });
    return book;
  }

  public async read(id: string): Promise<Book> {
    const book: Book = await this.prisma.book.findUnique({
      where: {
        id,
      },
    });
    return book;
  }

  public async readAll(): Promise<Book[]> {
    const books: Book[] = await this.prisma.book.findMany();
    return books;
  }

  public async update(id: string, dto: UpdateBookDTO): Promise<Book> {
    const where: { id: string } = { id };
    const data: UpdateBookDTO = {
      name: dto.name,
      author: dto.author,
      mark: dto.mark,
      volumesCount: dto.volumesCount,
      releaseDate: dto.releaseDate,
    };
    const book: Book = await this.prisma.book.update({
      where,
      data,
    });

    return book;
  }

  public async findWithVolumesCount(volumesCount: number): Promise<Book[]> {
    const books: Book[] = await this.prisma.book.findMany({
      where: {
        volumesCount,
      },
    });
    return books;
  }

  public async findWithName(name: string): Promise<Book[]> {
    const books: Book[] = await this.prisma.book.findMany({
      where: {
        name: {
          contains: name,
        },
      },
    });
    return books;
  }

  public async patch(id: string, dto: PatchBookDTO): Promise<Book> {
    const where: { id: string } = { id };
    const data: PatchBookDTO = {
      name: dto.name,
      author: dto.author,
      mark: dto.mark,
      volumesCount: dto.volumesCount,
      releaseDate: dto.releaseDate,
    };
    const book: Book = await this.prisma.book.update({
      where,
      data,
    });

    return book;
  }

  public async delete(id: string): Promise<Book> {
    const book: Book = await this.prisma.book.delete({
      where: {
        id,
      },
    });
    return book;
  }
}
