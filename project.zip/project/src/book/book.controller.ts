import { Controller, Query } from '@nestjs/common';
import { Body, Delete, Get, Param, Patch, Post, Put } from '@nestjs/common';
import { BookService } from './book.service';
import { CreateBookDTO, PatchBookDTO, UpdateBookDTO } from './book.dot';
import { Book } from '@prisma/client';

@Controller('books')
export class BookController {
  constructor(private bookService: BookService) {}

  @Post()
  public create(@Body() dto: CreateBookDTO): Promise<Book> {
    return this.bookService.create(dto);
  }

  @Get(':id')
  public findOne(@Param() params: { id: string }): Promise<Book> {
    console.log(params.id);
    return this.bookService.read(params.id);
  }

  @Get()
  public findMany(): Promise<Book[]> {
    return this.bookService.readAll();
  }

  @Get()
  async findBooksWithVolumesCount(
    @Query('volumesCount') volumesCount: number,
  ): Promise<Book[]> {
    console.log(1);
    return this.bookService.findWithVolumesCount(volumesCount);
  }

  @Get()
  async findWithName(@Query('name') name: string): Promise<Book[]> {
    return this.bookService.findWithName(name);
  }

  @Put(':id')
  public update(
    @Body() dto: UpdateBookDTO,
    @Param() params: { id: string },
  ): Promise<Book> {
    return this.bookService.update(params.id, dto);
  }

  @Patch(':id')
  public patch(
    @Param() params: { id: string },
    @Body() dto: PatchBookDTO,
  ): Promise<Book> {
    return this.bookService.patch(params.id, dto);
  }

  @Delete(':id')
  public delete(@Param() params: { id: string }): Promise<Book> {
    return this.bookService.delete(params.id);
  }
}
