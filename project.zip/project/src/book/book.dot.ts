import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateBookDTO {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsNumber()
  @IsNotEmpty()
  volumesCount: number;

  @IsString()
  @IsNotEmpty()
  author: string;

  @IsNumber()
  @IsNotEmpty()
  mark: number;

  @IsString()
  @IsNotEmpty()
  releaseDate: string;
}

export class UpdateBookDTO {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsNumber()
  @IsNotEmpty()
  volumesCount: number;

  @IsString()
  @IsNotEmpty()
  author: string;

  @IsNumber()
  @IsNotEmpty()
  mark: number;

  @IsString()
  @IsNotEmpty()
  releaseDate: string;
}

export class PatchBookDTO {
  @IsString()
  @IsOptional()
  name: string;

  @IsNumber()
  @IsOptional()
  volumesCount: number;

  @IsString()
  @IsOptional()
  author: string;

  @IsNumber()
  @IsOptional()
  mark: number;

  @IsString()
  @IsOptional()
  releaseDate: string;
}
