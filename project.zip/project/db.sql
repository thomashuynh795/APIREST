--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    "authorId" text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Post" OWNER TO postgres;

--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    name text NOT NULL,
    price integer DEFAULT 0 NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    password text NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Post" (id, "authorId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, name, price, description, quantity) FROM stdin;
2cfcd50b-5df4-40cc-b651-094e062ed2dd	x	0		0
f507817c-f4a3-4710-a5b3-f139ed270705	a	1	a	10
5cfd2a81-00d3-4796-9cb4-7d3a93d2af4c	velo	100	vtt rouge	1
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, name, "createdAt", password) FROM stdin;
6d50e5c6-92fe-4b65-8612-16ed785a22f0	x@email.net	x X	2024-03-21 07:17:08.791	password
32befb3a-5c7c-4422-b925-418f2ab7a241	a@email.net	x X	2024-03-21 10:16:57.343	$2b$10$.ys63j06l4VFgNMiaO/bXe8X28oxPvWBpE8BD3ym98iqlb8rEx6Ye
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
a12ab3a5-c6d7-49c7-8698-e24ea737224b	23a86e2369db98c99fdec859419347f3fe4e8ecd52e2f689e3c2c3e03a098063	2024-03-20 19:59:12.246398+00	20240320195912_	\N	\N	2024-03-20 19:59:12.228574+00	1
413f4c90-4da2-4ef5-b520-4dee7ff6cf53	5822c0180ac03aba40c14b9f12780b2803c70ba007380686c0e15df82bf9bc8a	2024-03-20 22:22:14.432971+00	20240320222214_	\N	\N	2024-03-20 22:22:14.420999+00	1
09fbd801-74e4-4d67-92da-e211b0035f93	09db6846c3ab9e701d42b632f10e43b7d7b15b5557f711f579dbb266298aef76	2024-03-21 07:30:26.409056+00	20240321073026_	\N	\N	2024-03-21 07:30:26.401392+00	1
157293e1-85d4-4904-a1ce-3f7308e675d5	76e9dba80e72abdd81df10de611aa8e18176405323ec4938a6388a5655d83288	2024-03-21 07:34:35.550915+00	20240321073435_	\N	\N	2024-03-21 07:34:35.540655+00	1
e93e311c-e434-4be5-adb0-6cebef7d2886	5333a15b566d08d30b55f6e9dbca567e90cb65ef7ef00a5d2b9aae351f4ff6ed	2024-03-21 07:45:37.653429+00	20240321074537_	\N	\N	2024-03-21 07:45:37.649847+00	1
\.


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Post Post_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

