-- CreateTable
CREATE TABLE "Book" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "volumesCount" INTEGER NOT NULL,
    "author" TEXT NOT NULL,
    "mark" INTEGER NOT NULL DEFAULT 0,
    "releaseDate" TEXT NOT NULL,

    CONSTRAINT "Book_pkey" PRIMARY KEY ("id")
);
